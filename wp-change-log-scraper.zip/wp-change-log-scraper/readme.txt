===WP Change Log Scraper===
Contributors: wpexpertsio
Tags: Change Log, WP Change Log, WordPress Get Change Log, Get WP Change Log, WP Plugin Change Log
Requires at least: 4.9
Requires PHP: 5.2
Tested up to: 4.9.4
Stable tag: 1.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl.html

== Description ==
WP Change Log Scraper Use To Get WordPress Plugin Change log by using Shortcode. Use ShortCode For Getting plugin Change loge and display any Where in page .


== Features ==
* Dynamically display change log.
* Just Copy the ShortCode and use it any where. 
* Easy to Use.
* Saves all changelog in cache to keep things optimized

== Installation ==
To add a WordPress Plugin using the built-in plugin installer:

Go to Plugins > Add New.

1. Type in the name \"WP Change Log Scraper\" in Search Plugins box
2. Find the \"WP Change Log Scraper\" Plugin you wish to install.
3. Click Install Now to install the WordPress Plugin.
4. The resulting installation screen will list the installation as successful or note any problems during the install.
If successful, click Activate Plugin to activate it, or return to plugin installer for further actions.

== Screenshots ==
1. Screenshot of WP Change Log Scraper before Adding Plugin Url.
2. Screenshot of WP Change Log Scraper After Adding Plugin Url.
3. Screenshot of WP Change Log Scraper Past The ShortCode.
4. Screenshot of WP Change Log Scraper View The Live Change Log Form WordPress.org .

== Changelog ==
 
= 1.0 =
- Initial release.

== Upgrade Notice ==
Always try to keep your plugin update so that you can get the improved and additional features added to this plugin till the moment.